#!/bin/sh

tar -cf dotfiles.tar.gz2 /dev/null

for file in $(ls -a -1 | grep -e "\..*" | grep -v ".*~")
do
    if [[ -f $file ]]; then
        tar -uf dotfiles.tar.gz2 $file
    fi
done
